## Motivation

A simple machine learning algorithm suite based on Professor Hsuan-Tien Lin, National Taiwan University, Machine Learning Foundations/Techniques course.

## Dataset

Most of them are provided ans published by Professor Hsuan-Tien Lin Machine Learning course.

## License

MIT
